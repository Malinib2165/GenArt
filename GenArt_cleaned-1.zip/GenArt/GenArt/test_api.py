import urllib.request
import urllib.parse

# Test the cartoonify API using urllib
url = 'http://127.0.0.1:5000/cartoonify'

# Simple way: use urllib to post
# But for multipart, it's complex. Let's use a simple test without file for now.

# Test without file to see if endpoint responds
try:
    response = urllib.request.urlopen(url)
    print('GET Status:', response.getcode())
except Exception as e:
    print('GET Error:', e)

# For POST, let's try a simple post without file
data = urllib.parse.urlencode({'effect': 'cartoon'}).encode()
req = urllib.request.Request(url, data=data, method='POST')
try:
    with urllib.request.urlopen(req) as response:
        print('POST Status:', response.getcode())
        print('Response:', response.read().decode('utf-8'))
except Exception as e:
    print('POST Error:', e)
