document.getElementById('upload-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const formData = new FormData();
    const fileInput = document.getElementById('image-upload');
    const effectSelect = document.getElementById('effect');

    formData.append('file', fileInput.files[0]);
    formData.append('effect', effectSelect.value);

    fetch('/cartoonify', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.processed_image) {
            displayImage(data.processed_image);
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        alert('Something went wrong. Please try again.');
    });
});

function displayImage(base64Image) {
    const inputImage = document.getElementById('input-image');
    const outputImage = document.getElementById('output-image');

    inputImage.src = URL.createObjectURL(document.getElementById('image-upload').files[0]);
    outputImage.src = base64Image;
}

document.getElementById('home-link').addEventListener('click', function(event) {
    event.preventDefault();
    const welcomeDiv = document.getElementById('welcome-message');
    const aboutDiv = document.getElementById('about-message');
    // Hide about message if visible
    if (aboutDiv.style.display === 'block') {
        aboutDiv.style.display = 'none';
    }
    // Toggle welcome message
    if (welcomeDiv.style.display === 'block') {
        welcomeDiv.style.display = 'none';
    } else {
        welcomeDiv.style.display = 'block';
    }
});

document.getElementById('about-link').addEventListener('click', function(event) {
    event.preventDefault();
    const welcomeDiv = document.getElementById('welcome-message');
    const aboutDiv = document.getElementById('about-message');
    // Hide welcome message if visible
    if (welcomeDiv.style.display === 'block') {
        welcomeDiv.style.display = 'none';
    }
    // Toggle about message
    if (aboutDiv.style.display === 'block') {
        aboutDiv.style.display = 'none';
    } else {
        aboutDiv.style.display = 'block';
    }
});
