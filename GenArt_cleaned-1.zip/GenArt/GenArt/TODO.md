# TODO List for Adding Disney Filter

- [x] Add disney effect in app.py apply_cartoon_effect function
- [x] Add Disney option to effect select in index.html
- [x] Update about message in index.html to mention 4 arts
